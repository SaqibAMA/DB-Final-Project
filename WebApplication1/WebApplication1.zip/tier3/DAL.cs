﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;


namespace WebApplication1.tier3
{
    public class DAL
    {
        static string connection_str = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Jamya;Integrated Security=True;Connect Timeout=15;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False;";

        //LOGIN SECTION
        public string isUserExists(string uname, string pass)
        {
            string email = "";
            using (SqlConnection sqlCon = new SqlConnection(connection_str))
            {
                sqlCon.Open();
                SqlCommand sqlCMD = sqlCon.CreateCommand();
                sqlCMD.CommandText = "isUsrExists";
                sqlCMD.CommandType = CommandType.StoredProcedure;
                sqlCMD.Parameters.AddWithValue("@username", uname);
                sqlCMD.Parameters.AddWithValue("@password", pass);
                sqlCMD.Parameters.Add("@email", SqlDbType.NVarChar, 50);
                sqlCMD.Parameters["@email"].Direction = ParameterDirection.Output;
                sqlCMD.ExecuteScalar();
                email = Convert.ToString(sqlCMD.Parameters["@email"].Value.ToString());
                sqlCon.Close();
            }
            return email;
        }
        public int getID(string eml)
        {
            int accID = 0;
            using (SqlConnection sqlCon = new SqlConnection(connection_str))
            {
                sqlCon.Open();
                SqlCommand sqlCMD = sqlCon.CreateCommand();
                sqlCMD.CommandText = "dbo.getID";
                sqlCMD.CommandType = CommandType.StoredProcedure;
                sqlCMD.Parameters.AddWithValue("@eml", eml);
                sqlCMD.Parameters.Add("@accID", SqlDbType.Int);
                sqlCMD.Parameters["@accID"].Direction = ParameterDirection.Output;
                sqlCMD.ExecuteScalar();
                accID = int.Parse(sqlCMD.Parameters["@accID"].Value.ToString());
                sqlCon.Close();
            }
            return accID;
        }
        public int isStudent(int accID)
        {
            int count = 0;
            using (SqlConnection sqlCon = new SqlConnection(connection_str))
            {
                sqlCon.Open();
                SqlCommand sqlCMD = sqlCon.CreateCommand();
                sqlCMD.CommandText = "dbo.isStudent";
                sqlCMD.CommandType = CommandType.StoredProcedure;
                sqlCMD.Parameters.AddWithValue("@accID", accID);
                sqlCMD.Parameters.Add("@count", SqlDbType.Int);
                sqlCMD.Parameters["@count"].Direction = ParameterDirection.Output;
                sqlCMD.ExecuteScalar();
                count = int.Parse(sqlCMD.Parameters["@count"].Value.ToString());
                sqlCon.Close();
            }
            return count;
        }
        public int isUniversity(int accID)
        {
            int count = 0;
            using (SqlConnection sqlCon = new SqlConnection(connection_str))
            {
                sqlCon.Open();
                SqlCommand sqlCMD = sqlCon.CreateCommand();
                sqlCMD.CommandText = "dbo.isUniversity";
                sqlCMD.CommandType = CommandType.StoredProcedure;
                sqlCMD.Parameters.AddWithValue("@accID", accID);
                sqlCMD.Parameters.Add("@count", SqlDbType.Int);
                sqlCMD.Parameters["@count"].Direction = ParameterDirection.Output;
                sqlCMD.ExecuteScalar();
                count = int.Parse(sqlCMD.Parameters["@count"].Value.ToString());
                sqlCon.Close();
            }
            return count;
        }
        public void stdName(int accID, ref string fName, ref string lName)
        {
            using (SqlConnection sqlCon = new SqlConnection(connection_str))
            {
                sqlCon.Open();
                SqlCommand sqlCMD = sqlCon.CreateCommand();
                sqlCMD.CommandText = "dbo.stdDetails";
                sqlCMD.CommandType = CommandType.StoredProcedure;
                sqlCMD.Parameters.AddWithValue("@accID", accID);
                sqlCMD.Parameters.Add("@fName", SqlDbType.VarChar, 20);
                sqlCMD.Parameters["@fName"].Direction = ParameterDirection.Output;
                sqlCMD.Parameters.Add("@lName", SqlDbType.VarChar, 20);
                sqlCMD.Parameters["@lName"].Direction = ParameterDirection.Output;
                sqlCMD.ExecuteScalar();
                fName = Convert.ToString(sqlCMD.Parameters["@fName"].Value.ToString());
                lName = Convert.ToString(sqlCMD.Parameters["@lName"].Value.ToString());
                sqlCon.Close();
            }
        }
        public string uniName(int accID)
        {
            string name = "";
            using (SqlConnection sqlCon = new SqlConnection(connection_str))
            {
                sqlCon.Open();
                SqlCommand sqlCMD = sqlCon.CreateCommand();
                sqlCMD.CommandText = "dbo.uniName";
                sqlCMD.CommandType = CommandType.StoredProcedure;
                sqlCMD.Parameters.AddWithValue("@accID", accID);
                sqlCMD.Parameters.Add("@uName", SqlDbType.VarChar, 50);
                sqlCMD.Parameters["@uName"].Direction = ParameterDirection.Output;
                sqlCMD.ExecuteScalar();
                name = Convert.ToString(sqlCMD.Parameters["@uName"].Value.ToString());
                sqlCon.Close();
            }
            return name;
        }
        //University SIGNUP Section
        public void isAlreadyUsr(string username, string email, ref int ucount, ref int ecount)
        {
            int count = 0;
            using (SqlConnection sqlCon = new SqlConnection(connection_str))
            {
                sqlCon.Open();
                SqlCommand sqlCMD = sqlCon.CreateCommand();
                sqlCMD.CommandText = "dbo.isAlreadyUsr";
                sqlCMD.CommandType = CommandType.StoredProcedure;
                sqlCMD.Parameters.AddWithValue("@username", username);
                sqlCMD.Parameters.AddWithValue("@email", email);
                sqlCMD.Parameters.Add("@ucount", SqlDbType.Int);
                sqlCMD.Parameters["@ucount"].Direction = ParameterDirection.Output;
                sqlCMD.Parameters.Add("@ecount", SqlDbType.Int);
                sqlCMD.Parameters["@ecount"].Direction = ParameterDirection.Output;
                sqlCMD.ExecuteScalar();
                ucount = int.Parse(sqlCMD.Parameters["@ucount"].Value.ToString());
                ecount = int.Parse(sqlCMD.Parameters["@ecount"].Value.ToString());
                sqlCon.Close();
            }
        }
        public void uniSignup(string username, string email, string password, string uName, string address, string contact)
        {
            using (SqlConnection sqlCon = new SqlConnection(connection_str))
            {
                sqlCon.Open();
                SqlCommand sqlCMD = sqlCon.CreateCommand();
                sqlCMD.CommandText = "dbo.uniSignup";
                sqlCMD.CommandType = CommandType.StoredProcedure;
                sqlCMD.Parameters.AddWithValue("@username", username);
                sqlCMD.Parameters.AddWithValue("@email", email);
                sqlCMD.Parameters.AddWithValue("@password", password);
                sqlCMD.Parameters.AddWithValue("@uName", uName);
                sqlCMD.Parameters.AddWithValue("@address", address);
                sqlCMD.Parameters.AddWithValue("@contact", contact);
                sqlCMD.ExecuteScalar();
                sqlCon.Close();
            }
        }
        public void stdSignup(string username, string email, string password, string fName, string lName, string defaultdate)
        {
            using (SqlConnection sqlCon = new SqlConnection(connection_str))
            {
                sqlCon.Open();
                SqlCommand sqlCMD = sqlCon.CreateCommand();
                sqlCMD.CommandText = "dbo.stdSignup";
                sqlCMD.CommandType = CommandType.StoredProcedure;
                sqlCMD.Parameters.AddWithValue("@username", username);
                sqlCMD.Parameters.AddWithValue("@email", email);
                sqlCMD.Parameters.AddWithValue("@password", password);
                sqlCMD.Parameters.AddWithValue("@fName", fName);
                sqlCMD.Parameters.AddWithValue("@lName", lName);
                sqlCMD.Parameters.AddWithValue("@defaultdate", defaultdate);
                sqlCMD.ExecuteScalar();
                sqlCon.Close();
            }
        }
    }
}